﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim b As String
        b = TextBox1.Text
        Try
            If (b = "") Then
                Throw New NullReferenceException
            Else
                Form2.Show()
            End If

        Catch ex As NullReferenceException
            TextBox3.Visible = True
            TextBox3.Text = "Please Enter Name"
        End Try




    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False

        RadioButton1.Checked = False
        RadioButton2.Checked = False
        RadioButton3.Checked = False









    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox3.Visible = False
    End Sub
End Class
