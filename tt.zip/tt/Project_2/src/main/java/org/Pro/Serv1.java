package org.Pro;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Servlet implementation class Serv1
 */
public class Serv1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Stdnt s=new Stdnt();
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String name=request.getParameter("nm");
		int roll=Integer.parseInt( request.getParameter("rl"));
		String city=request.getParameter("ct");
		String gen=request.getParameter("gen");
		String pass=request.getParameter("pass");
		String pass1=request.getParameter("pass1");
		String uid=request.getParameter("ud");
		if(pass.equals(pass1))
		{
			s.setCity(city);
			s.setName(name);
			s.setGender(gen);
			s.setRoll(roll);
			s.setPassword(pass);
			s.setUserid(uid);
			SessionFactory factory=new Configuration().configure().addAnnotatedClass(Stdnt.class).buildSessionFactory();
			Session session=factory.openSession();
			
			try {
				session.beginTransaction();
				session.save(s);
				session.getTransaction().commit();
			} catch (Exception e) {
				System.out.println(e);
			}
			finally {
				session.close();
			}
		}
		else
		{
			out.print("Password Doesnot match..");
		}
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
