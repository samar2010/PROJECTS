package org.Pro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Stdnt")
public class Stdnt {
	 @Id
	 @Column(name = "roll")
		int roll;
	 
	@Column(name = "name")
	String name;
	 
	@Column(name = "city")
		String city;
	 @Column(name = "userid")
		String userid;
	 @Column(name = "gender")
		String gender;
	
	 @Column(name = "password")
		String password;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public String getUserid() {
	return userid;
}

public void setUserid(String userid) {
	this.userid = userid;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public int getRoll() {
	return roll;
}

public void setRoll(int roll) {
	this.roll = roll;
}
   
}
