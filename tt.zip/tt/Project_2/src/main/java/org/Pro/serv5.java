package org.Pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class serv5
 */
public class serv5 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public serv5() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
	    response.setContentType("text/html");
	    String roll=request.getParameter("nm");
	    
	    
	    Connection cn;
	    Statement st;
	    ResultSet rs;
	   
	    
	    try {
	    	Class.forName("oracle.jdbc.driver.OracleDriver"); 
	    	
	    	
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			
			st=cn.createStatement();
			
			 rs=st.executeQuery("select * from stdnt where roll='"+roll+"'");
			 
					 out.print("<table border=1>");
					 out.print("<tr><td>"+"ROLL"+"</td><td>"+"CITY"+"</td><td>"+"GENDER"+"</td><td>"+"NAME"+"</td><td>"+"PASSWORD"+"</td><td>"+"USERID"+"</td></tr>");
					   while(rs.next())
					   {
						   out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td>" + "<td>" + rs.getString(6) +"</td></tr>");
					   }
					   out.print("</table>");
						rs.close();
					   st.close();
						cn.close();
				}
catch(Exception e) {
			
		}
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
