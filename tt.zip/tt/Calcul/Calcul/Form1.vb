﻿Public Class Form1
    Dim fn, sn As Single


    Dim operations As Integer
    Dim operator_selector As Boolean = False
    Private Sub Button17_Click(sender As Object, e As EventArgs)
        TextBox1.Text = "."

    End Sub
    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        If operator_selector = True Then
            If operations = 1 Then
                sn = TextBox1.Text

                TextBox1.Text = fn + sn
            ElseIf operations = 2 Then
                sn = TextBox1.Text

                TextBox1.Text = fn - sn
            ElseIf operations = 3 Then
                sn = TextBox1.Text

                Try

                    If (sn = 0) Then
                        Throw New DivideByZeroException()
                    Else
                        TextBox1.Text = fn / sn
                    End If
                Catch ex As DivideByZeroException
                    TextBox1.Text = "ERROR!"
                End Try



            ElseIf operations = 4 Then
                sn = TextBox1.Text

                TextBox1.Text = fn * sn
            End If
            operator_selector = False
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox1.Text = "1"

    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = "2"

    End Sub



    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TextBox1.Text = "3"

    End Sub




    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox1.Text = "4"

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        TextBox1.Text = "5"

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        TextBox1.Text = "6"

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        TextBox1.Text = "7"

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        TextBox1.Text = ("8")

    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        TextBox1.Text = "9"

    End Sub
    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        TextBox1.Text = "0"

    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        fn = TextBox1.Text
        TextBox1.Text += "+"
        operator_selector = True
        operations = 1
    End Sub
    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        fn = TextBox1.Text
        TextBox1.Clear()
        TextBox1.Text += "-"
        operator_selector = True
        operations = 2
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        fn = TextBox1.Text
        TextBox1.Clear()
        TextBox1.Text += "/"
        operator_selector = True
        operations = 3
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        fn = TextBox1.Text
        TextBox1.Clear()

        TextBox1.Text += "*"
        operator_selector = True
        operations = 4
    End Sub
    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        TextBox1.Text = "0"

   

    End Sub

   
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class
