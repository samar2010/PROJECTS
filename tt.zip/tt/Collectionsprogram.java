


	import java.util.ArrayList;
	import java.util.Iterator;
	import java.util.Scanner;
	class a
	{
		String ele,ele1,ele2;
		String empcode;
		String name;
		String address;
		String salary;
		ArrayList<String> list=new ArrayList<String>();
		Scanner s;
		


	public void listing()
	{
		s=	new Scanner(System.in);
		System.out.println("Enter Employee code :");
		empcode =s.nextLine();
		System.out.println("Enter Employee name :");
		name = s.nextLine();
		System.out.println("Enter Employee salary :");
	    salary =s.nextLine();
		System.out.println("Enter Employee address :");
	    address =s.next();



	list.add(name);
	list.add(empcode);
	list.add(salary);
	list.add(address);

	Iterator itr=list.iterator();
	while(itr.hasNext()){  
	System.out.println(itr.next());
	}
	}

	 public void delete()
	 {
		 s=	new Scanner(System.in);
	System.out.println("enter element which you want to delete");
	 ele=s.nextLine();

	if(ele.equals("name"))
	{
		list.set(0,"" );
		System.out.println("deleted");
		
	}


	else if(ele.equals("salary"))
	{
		list.set(2,"" );
		System.out.println("new list after deleted");
		
	}


	else if(ele.equals("empcode"))
	{
		list.set(1,"" );
		System.out.println("new list after deleted");
		
	}


	else if(ele.equals("address"))
	{
		list.set(3,"" );
		System.out.println("deleted");
		
		
	}
	else
	{
		System.out.println("no such field");
	}

	Iterator itr=list.iterator();
	System.out.println("after deletion");
	while(itr.hasNext()){  
	System.out.println(itr.next());
	}


	}
	 public void update()
	 {
		 s=	new Scanner(System.in);
	System.out.println("enter element which you want to update");
	 ele1=s.nextLine();
	 System.out.println("enter element's value");
	 ele2=s.nextLine();
	if(ele1.equals("name"))
	{
		list.set(0,ele2 );
		System.out.println("updated");
		
	}


	else if(ele1.equals("empcode"))
	{
		list.set(1, ele2);
		System.out.println("updated");
		
	}


	else if(ele1.equals("salary"))
	{
		list.set(2, ele2);
		System.out.println("updated");
		
	}


	else if(ele1.equals("address"))
	{
		list.set(3, ele2);
		System.out.println("updated");
		
		
	}
	else
	{
		System.out.println("no such field");
	}

	Iterator itr=list.iterator();
	System.out.println("after updation");
	while(itr.hasNext()){  
	System.out.println(itr.next());
	}



	}



	}


	public class Collectionsprogram {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
	a a1 =new a();
	a1.listing();
	a1.delete();
	a1.update();
	
		}

	}
