package Project.Project9;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/data")
public class Sudentdata {
@GET
@Path("/add/{roll}/{name}/{age}/{city}")
public String getdata(@PathParam("roll")String roll,@PathParam("name")String name,@PathParam("age")String age,@PathParam("city")String city) {
		
	Connection cn;
    Statement smt;
    ResultSet rs;
    
    try 
    {
   	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
   	 //Register Driver
   	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
   	
		smt=cn.createStatement();
		smt.executeUpdate("insert into student values('"+roll+"','"+name+"','"+age+"','"+city+"')");
		smt.close();
		cn.commit();
	   	cn.close();
		
   	
    }
    catch(Exception e)
    {
   	  
    }
    return "Data Saved Successfully";
}

@GET
@Path("/del/{roll}")
public String deldata(@PathParam("roll")String roll){
	Connection cn;
    Statement smt;
    ResultSet rs;
    
    try 
    {
   	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
   	 //Register Driver
   	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
   	
		smt=cn.createStatement();
		smt.executeUpdate("delete from student where rollno=" + roll);
		smt.close();
		cn.commit();
	   	cn.close();
		
   	
    }
    catch(Exception e)
    {
   	  
    }
    return "Data deleted Successfully";
}

@GET
@Path("/upd/{roll}")
public String updatedata(@PathParam("roll")String roll){
	Connection cn;
    Statement smt;
    ResultSet rs;
    
    try 
    {
   	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
   	 //Register Driver
   	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
   	
		smt=cn.createStatement();
		smt.executeUpdate("UPDATE student SET CITY = 'MUMBAI' where rollno=" + roll);
		smt.close();
		cn.commit();
	   	cn.close();
		
   	
    }
    catch(Exception e)
    {
   	  
    }
    return "Data updated Successfully";
}

@GET
@Path("/show")
public String showdata(@PathParam("roll")String roll){
	Connection cn;
    Statement smt;
    
    
    try 
    {
   	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
   	 //Register Driver
   	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
   	
		smt=cn.createStatement();
		ResultSet rs = smt.executeQuery("select * from student");
		while(rs.next())
		{
			String roll1=rs.getString(1);
			String name1=rs.getString(2);
			String age1=rs.getString(3);
			String city1=rs.getString(4);
			System.out.println(roll1 + " " + name1 + " " + age1 + " " + city1);
		}
		smt.close();
		cn.commit();
	   	cn.close();
		
   	
    }
    catch(Exception e)
    {
   	  
    }
    return "Data shown Successfully";
}



}
