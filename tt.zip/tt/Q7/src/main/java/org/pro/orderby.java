package org.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class orderby
 */
public class orderby extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public orderby() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		 Connection cn;
			Statement smt;
			ResultSet rs;
			ResultSet rs2;
			
			
			
		    try 
		     {
		    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
		    	 //Register Driver
		    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		    	
				 smt=cn.createStatement();
			     rs=smt.executeQuery("select * from stud order by percent desc");
			     
			    
			     out.println("<center>");
		        	out.println("RESULTS");
		        	out.println("<hr/>");
			       out.println("<table border=1>");
		           out.println("<tr><td>" + "NAME" + "</td>" + "<td>" + "ROLLNO" + "</td>" + "<td>" + "PHYSICS" + "</td>" + "<td>" + "CHEMISTRY" + "</td>" + "<td>" + "MATHS" + "</td>" + "<td>" + "HINDI" + "</td>" + "<td>" + "ENGLISH" + "</td> " + "<td>" + "PERCENTAGE" + "</td></tr>");  
           while(rs.next())
           {
        	   
        	                                                     
           out.println("<tr><td>" + rs.getString(1) + "</td>" + "<td>" + rs.getString(2) + "</td>" + "<td>" + rs.getString(3) + "</td>" + "<td>" + rs.getString(4) + "</td>" + "<td>" + rs.getString(5) + "</td>" + "<td>" + rs.getString(6) + "</td>" + "<td>" + rs.getString(7) + "</td>" + "<td>" + rs.getString(8) + "</td></tr>");
           
           
           out.println("</center>");
           }
           cn.commit();
           smt.close();
	    	cn.close();

				
		     }
		     catch(Exception e)
		     {
		    	 
		     } 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
