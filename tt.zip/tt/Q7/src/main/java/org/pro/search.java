package org.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class search
 */
public class search extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public search() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String se=request.getParameter("se");
		 Connection cn;
			Statement smt;
			ResultSet rs;
			
			
			
		    try 
		     {
		    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
		    	 //Register Driver
		    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		    	
				 smt=cn.createStatement();
			     rs=smt.executeQuery("select * from stud where rollno=" + se);
			     
			    
			     
           while(rs.next())
           {
        	
        	
        	
        	out.println("<center>");
        	out.println("<h1 style=color:blue>CONGRATS</h1>");
        	out.println("<hr/>");
	       out.println("<table border=1>");
           out.println("<tr><td>" + "NAME" + "</td>" + "<td>" + "ROLLNO" + "</td>" + "<td>" + "PERCENTAGE" + "</td>" + "<td>" + "GRADE" + "</td></tr>");
           out.println("<tr><td>" + rs.getString(1) + "</td>" + "<td>" + rs.getString(2) + "</td>" + "<td>" + rs.getString(8) + "</td>" + "<td>" + rs.getString(9) + "</td></tr>");
           out.println("</table>");
           
           out.println("</center>");
           
           }
           smt.close();
	    	cn.close();

				
		     }
		     catch(Exception e)
		     {
		    	 
		     } 
		   
			}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
